from .models import *
from django import forms


class BlogdataForm(forms.ModelForm):

    class Meta:
        model=Blogdata
        fields=['title','content']
        exclude=['publish_date']

        widgets = {
            'title': forms.TextInput(
				attrs={
					'class': 'form-control'
					}
				),
            'content': forms.Textarea(
				attrs={
					'class': 'form-control'
					}
				),
			}
        